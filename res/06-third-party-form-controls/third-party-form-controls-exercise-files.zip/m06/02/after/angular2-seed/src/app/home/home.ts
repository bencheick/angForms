import {Component} from '@angular/core';

@Component({
  selector: 'home',
  styleUrls: ['./home.css'],
  templateUrl: './home.html'
})
export class Home {
  rating = 0;
  startDate: Date;// = new Date("Jan 1 2017");
  startTime = new Date(Date.now());
  switch = "0";
  taxStatus = "W2";
  minDate = new Date(Date.now());
  constructor() {
    
  }

  leaveRating(value) {
    console.log('leave: ' + value);
  }
}
