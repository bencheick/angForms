import {Component} from '@angular/core';

@Component({
  selector: 'home',
  styleUrls: ['./home.css'],
  templateUrl: './home.html'
})
export class Home {
  minDate = new Date('Oct 12 2016');
  onOffSwitch = "Off";
  postRating = 5;
  startDate: Date;
  startTime = new Date('Oct 1 2016 3:00 PM');
  taxType = 'W2';

  hover(value) {
    console.log("hover: " + value);
  }

  leave(value) {
    console.log("leave: " + value);
  }


}
